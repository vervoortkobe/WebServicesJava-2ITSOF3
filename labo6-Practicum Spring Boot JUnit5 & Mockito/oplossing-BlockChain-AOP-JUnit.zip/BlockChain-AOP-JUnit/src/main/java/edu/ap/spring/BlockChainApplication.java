package edu.ap.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlockChainApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(BlockChainApplication.class, args);
	}
}
