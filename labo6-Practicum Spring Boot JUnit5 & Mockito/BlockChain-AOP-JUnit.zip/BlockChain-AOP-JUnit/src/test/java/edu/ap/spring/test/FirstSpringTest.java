package edu.ap.spring.test;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.mockito.Mockito;
import edu.ap.spring.service.*;
import edu.ap.spring.transaction.Transaction;

@SpringBootTest
public class FirstSpringTest {

	
}
