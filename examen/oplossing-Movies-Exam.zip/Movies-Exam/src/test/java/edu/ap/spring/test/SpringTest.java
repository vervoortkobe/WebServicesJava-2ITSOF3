package edu.ap.spring.test;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;

import org.junit.jupiter.api.*;

@Configuration
@SpringBootTest
public class SpringTest {

    @Test
    public void testSearchovieByActor() {

    }
}
