package ap.spring.herexamen.boekenproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoekenprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
