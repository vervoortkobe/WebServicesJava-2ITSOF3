package com.example.redis_examen_vraag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedisExamenVraagApplication {


    public static void main(String[] args) {
        SpringApplication.run(RedisExamenVraagApplication.class, args);
    }


}
