package com.example.redis_examen_vraag;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedisExamenVraagApplicationTests {

    @Test
    void contextLoads() {
    }

}
